const CONFIG = {
  phone: "5581993829286",
  produtos: [
    {nome:"Flamengo 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"Palmeiras 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"Corinthians 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"São Paulo 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"Atlético-MG 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"Real Madrid 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"Barcelona 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"PSG Jordan", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"Manchester City 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]},
    {nome:"Bayern de Munique 23/24", imagens:["#","#","#"], tamanhos:["P","M","G","GG"]}
  ]
};

let carrinho=[];
function renderProdutos(){
  const grid=document.getElementById("produtos");
  grid.innerHTML="";
  CONFIG.produtos.forEach((p,i)=>{
    const card=document.createElement("div");
    card.className="card";
    card.innerHTML=`<img src="${p.imagens[0]}" alt="${p.nome}">
      <div class="card-body"><h4>${p.nome}</h4>
      <p>R$139</p>
      <label>Tamanho:<select id="size${i}">${p.tamanhos.map(t=>`<option>${t}</option>`)}</select></label>
      <div><label><input type="checkbox" value="nome">Nome (+15)</label>
      <label><input type="checkbox" value="numero">Número (+15)</label>
      <label><input type="checkbox" value="ambos">Ambos (+20)</label></div>
      <button onclick="addCarrinho(${i})" class="btn-lg">Adicionar</button></div>`;
    grid.appendChild(card);
  });
}
function addCarrinho(i){
  const size=document.getElementById("size"+i).value;
  const checks=[...document.querySelectorAll(`#produtos .card:nth-child(${i+1}) input:checked`)].map(c=>c.value);
  carrinho.push({nome:CONFIG.produtos[i].nome,tamanho:size,personal:checks});
  renderCarrinho();
}
function renderCarrinho(){
  const el=document.getElementById("itensCarrinho");
  el.innerHTML="";
  let total=0;
  carrinho.forEach((item,idx)=>{
    let preco=139;
    if(item.personal.includes("nome")) preco+=15;
    if(item.personal.includes("numero")) preco+=15;
    if(item.personal.includes("ambos")) preco+=20;
    total+=preco;
    el.innerHTML+=`<div><b>${item.nome}</b> (${item.tamanho}) - Personalização: ${item.personal.join(",")||"Nenhuma"} - R$${preco} <button onclick="remover(${idx})">X</button></div>`;
  });
  const cupom=document.getElementById("cupom").value.trim().toUpperCase();
  let desconto=0;
  if(["CUPOMINSTA","CUPOMIG"].includes(cupom)) desconto=0.10;
  if(["CUPOMAL","CUPOMHE"].includes(cupom)) desconto=0.12;
  if(desconto>0){total=total-(total*desconto);}
  document.getElementById("total").innerText="Total: R$"+total.toFixed(2);
}
function remover(i){carrinho.splice(i,1);renderCarrinho();}
document.getElementById("cupom").addEventListener("input",renderCarrinho);
document.getElementById("finalizar").addEventListener("click",()=>{
  if(!carrinho.length){alert("Carrinho vazio!");return;}
  const cupom=document.getElementById("cupom").value.trim();
  let msg="Olá, quero finalizar meu pedido:\n";
  carrinho.forEach(c=>{msg+=`- ${c.nome} (${c.tamanho}) Personalização: ${c.personal.join(",")||"Nenhuma"}\n`;});
  msg+="Cupom: "+cupom+"\nForma de pagamento: PIX ou cartão";
  window.open(`https://wa.me/${CONFIG.phone}?text=${encodeURIComponent(msg)}`,"_blank");
});

// Countdown por visitante
function iniciarCountdown(){
  const key="fenix_timer";
  let end=localStorage.getItem(key);
  if(!end){end=Date.now()+72*60*60*1000;localStorage.setItem(key,end);}
  function atualizar(){
    let diff=end-Date.now();
    if(diff<=0){document.getElementById("countdown").innerText="Promoção encerrada";return;}
    let h=Math.floor(diff/1000/60/60);
    let m=Math.floor(diff/1000/60)%60;
    let s=Math.floor(diff/1000)%60;
    document.getElementById("countdown").innerText=`Termina em ${h}h ${m}m ${s}s`;
    requestAnimationFrame(atualizar);
  }
  atualizar();
}
iniciarCountdown();
document.getElementById("ano").innerText=new Date().getFullYear();
renderProdutos();
